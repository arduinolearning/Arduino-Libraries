MCP3008 is Arduino Library for communicating with MCP3008 Analog to digital converter.
Created by Uros Petrevski, Nodesign.net 2013
Released into the public domain.

ported from Python code originaly written by Adafruit learning system for rPI :
http://learn.adafruit.com/send-raspberry-pi-data-to-cosm/python-script


MCP3008 VDD -> 5V or 3.3V 

MCP3008 VREF -> 5V or 3.3V

MCP3008 AGND -> GND

MCP3008 CLK -> arduino gpio

MCP3008 DOUT -> arduino gpio

MCP3008 DIN -> arduino gpio

MCP3008 CS -> arduino gpio

MCP3008 DGND -> GND

Copy files inside "libraries" folder in principal sketch folder (where are all your sketches)

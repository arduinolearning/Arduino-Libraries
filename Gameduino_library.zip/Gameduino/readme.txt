Gameduino library
=================

Installation
------------

Place the entire folder as a subfolder in your Arduino libraries folder.
Restart your Arduino application.

To use this library in a sketch, go to the Sketch | Import Library menu and
select Gameduino.

This library features many examples. After installation, you can find them under
File | Examples | Gameduino.  'selftest' is a good example to start with, since it
runs a series of hardware tests (note that the flash test fails because we use 
different flash memory. The software is configured for AT45DB021D and we use AT45DB041D. 
The flash we mount is actually bigger than the original one. If the board has defective 
flash memory it won’t load any code - even the selftest)..


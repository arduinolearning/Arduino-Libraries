LoL-Shield
==========

LoL Shield Sketches

These are my personal sketches for the LoL Shield for Arduino.

LoL Shield is designed by Jimmie Rodgers:
http://jimmieprodgers.com/kits/lolshield/

This needs the Charliplexing library, which you can get at the LoL Shield project page:
http://code.google.com/p/lolshield/
